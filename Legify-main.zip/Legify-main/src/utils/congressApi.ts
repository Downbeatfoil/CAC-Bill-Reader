const CONGRESS_API_KEY = 'cdNakFqunVtj1V2oxFCQ7DsXxWLpCSdn2ai6H7va';

export const fetchRepresentativeImage = async (name: string): Promise<string | null> => {
  try {
    const response = await fetch(`https://api.congress.gov/v3/member?api_key=${CONGRESS_API_KEY}&format=json&name=${encodeURIComponent(name)}`);
    const data = await response.json();
    
    if (data.members && data.members.length > 0) {
      const member = data.members[0];
      return member.depiction?.imageUrl || null;
    }
    return null;
  } catch (error) {
    console.error('Error fetching representative image:', error);
    return null;
  }
};