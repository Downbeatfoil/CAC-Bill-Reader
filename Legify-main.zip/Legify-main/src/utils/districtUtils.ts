export const getDistrictNumber = (offices: Array<{ name: string; divisionId: string; officialIndices: number[] }> | undefined): string => {
  if (!offices) return 'Unknown';
  
  const congressionalOffice = offices.find(office => 
    office.name.toLowerCase().includes('united states representative') ||
    office.name.toLowerCase().includes('u.s. representative')
  );

  if (congressionalOffice) {
    const match = congressionalOffice.divisionId.match(/\/cd:(\d+)$/);
    if (match && match[1]) {
      return match[1];
    }
  }

  return 'At-Large';
};