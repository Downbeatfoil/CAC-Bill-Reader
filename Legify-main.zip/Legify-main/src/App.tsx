import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ThemeProvider } from './components/ThemeProvider';
import Navbar from './components/Navbar';
import VerticalProgressBar from './components/VerticalProgressBar';
import HomePage from './pages/HomePage';
import BillSummarizer from './pages/BillSummarizer';
import NewBills from './pages/NewBills';
import FindRepresentative from './pages/FindRepresentative';

const queryClient = new QueryClient();

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light" storageKey="vite-ui-theme">
        <Router>
          <div className="min-h-screen flex flex-col bg-gradient-to-br from-green-400 to-blue-500 dark:from-green-900 dark:to-blue-900">
            <Navbar />
            <VerticalProgressBar />
            <div className="flex-grow overflow-hidden">
              <div className="h-full overflow-auto pt-16">
                <Routes>
                  <Route path="/" element={<HomePage />} />
                  <Route path="/summarize" element={<BillSummarizer />} />
                  <Route path="/new-bills" element={<NewBills />} />
                  <Route path="/find-representative" element={<FindRepresentative />} />
                </Routes>
              </div>
            </div>
          </div>
        </Router>
      </ThemeProvider>
    </QueryClientProvider>
  );
};

export default App;