import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ExternalLink } from 'lucide-react';
import { Button } from "@/components/ui/button";

interface Bill {
  id: string;
  title: string;
  description: string;
  url: string;
  billNumber: string;
}

interface NewsArticle {
  id: string;
  title: string;
  source: string;
  url: string;
}

interface LegislationGroup {
  bill: Bill;
  relatedNews: {
    [key: string]: NewsArticle;
  };
}

const newsSources = [
  { name: 'CNN', logo: 'https://cdn.cnn.com/cnn/.e/img/3.0/global/misc/cnn-logo.png' },
  { name: 'New York Times', logo: 'https://static01.nyt.com/images/misc/NYT_logo_rss_250x40.png' },
  { name: 'Fox News', logo: 'https://hatchwise.com/wp-content/uploads/2023/08/Fox-News-Channel-Emblem-1024x576.png' },
  { name: 'Washington Post', logo: 'https://cdn.shopify.com/s/files/1/2143/6539/files/WP-logo.png?height=628&pad_color=fff&v=1614292069&width=1200' }
];

const fetchLegislationGroups = async (): Promise<LegislationGroup[]> => {
  // Simulated API call
  return [
    {
      bill: { 
        id: '1', 
        title: 'Climate Change Education Act', 
        description: 'A bill to promote education and awareness about climate change in schools and communities.', 
        url: 'https://www.congress.gov/bill/118th-congress/senate-bill/4117/text',
        billNumber: 'S.4117'
      },
      relatedNews: {
        'CNN': { id: '1', title: 'CNN: Analysis of the Climate Change Education Act', source: 'CNN', url: 'https://cnn.com/climate-education-analysis' },
        'New York Times': { id: '1', title: 'NYT: Impact of the Climate Change Education Act', source: 'New York Times', url: 'https://nytimes.com/climate-education-analysis' },
        'Fox News': { id: '1', title: 'Education reform \'accelerated,\' \'fueled\' by \'post-pandemic concerns\' from parents: report', source: 'Fox News', url: 'https://www.foxnews.com/media/education-reform-accelerated-fueled-post-pandemic-concerns-parents-report' },
        'Washington Post': { id: '1', title: 'WP: Experts Weigh In on Climate Change Education Act', source: 'Washington Post', url: 'https://washingtonpost.com/climate-education-analysis' },
      },
    },
    {
      bill: { 
        id: '2', 
        title: 'Protecting Health Care for All Patients Act', 
        description: 'A comprehensive bill aimed at ensuring equitable access to quality healthcare for all citizens, regardless of their socioeconomic status or pre-existing conditions.', 
        url: 'https://example.com/healthcare-protection-bill',
        billNumber: 'H.R.485'
      },
      relatedNews: {
        'CNN': { id: '2', title: 'Biden administration issues new rule to protect privacy of those seeking reproductive health care: \'No one should have to live in fear\'', source: 'CNN', url: 'https://www.cnn.com/2024/04/22/health/biden-administration-new-rule-reproductive-health-care-privacy/index.html' },
        'New York Times': { id: '2', title: 'NYT: Impact of the Protecting Health Care for All Patients Act', source: 'New York Times', url: 'https://nytimes.com/healthcare-protection-analysis' },
        'Fox News': { id: '2', title: 'Fox: Debate Surrounding the Protecting Health Care for All Patients Act', source: 'Fox News', url: 'https://foxnews.com/healthcare-protection-analysis' },
        'Washington Post': { id: '2', title: 'WP: Healthcare Experts Weigh In on Protecting Health Care for All Patients Act', source: 'Washington Post', url: 'https://washingtonpost.com/healthcare-protection-analysis' },
      },
    },
    {
      bill: { 
        id: '3', 
        title: 'Higher Education Reform and Opportunity Act', 
        description: 'A bill to reform higher education, improve accessibility, and create more opportunities for students across the nation.', 
        url: 'https://example.com/higher-education-reform-bill',
        billNumber: 'S.2629'
      },
      relatedNews: {
        'CNN': { id: '3', title: 'CNN: Higher Education Reform and Opportunity Act Explained', source: 'CNN', url: 'https://cnn.com/higher-education-reform' },
        'New York Times': { id: '3', title: 'NYT: The Future of Higher Education: Reform Act Analysis', source: 'New York Times', url: 'https://nytimes.com/higher-education-reform' },
        'Fox News': { id: '3', title: 'Fox: Debating the Higher Education Reform and Opportunity Act', source: 'Fox News', url: 'https://foxnews.com/higher-education-reform' },
        'Washington Post': { id: '3', title: 'WP: Higher Education Professionals React to Reform and Opportunity Act', source: 'Washington Post', url: 'https://washingtonpost.com/higher-education-reform' },
      },
    },
  ];
};

const NewBills = () => {
  const [selectedSources, setSelectedSources] = useState<{ [key: string]: string }>({});
  const { data: legislationGroups, isLoading } = useQuery({
    queryKey: ['legislationGroups'],
    queryFn: fetchLegislationGroups,
  });

  const handleSourceSelect = (billId: string, source: string) => {
    setSelectedSources(prev => ({ ...prev, [billId]: source }));
  };

  return (
    <div className="container mx-auto px-4 py-12 h-full overflow-auto no-scrollbar">
      <h1 className="text-4xl font-bold text-center text-white mb-12">Latest Bills and Related News</h1>
      
      {isLoading ? (
        <div className="space-y-8">
          {[...Array(3)].map((_, index) => (
            <Card key={index} className="w-full">
              <CardHeader>
                <Skeleton className="h-6 w-3/4 mb-2" />
                <Skeleton className="h-4 w-1/2" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-2/3" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="space-y-8">
          {legislationGroups?.map((group) => (
            <Card key={group.bill.id} className="w-full transition-all duration-300 hover:shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center justify-between text-2xl">
                  <span>{group.bill.title}</span>
                  <a href={group.bill.url} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:text-blue-700">
                    <ExternalLink size={20} />
                  </a>
                </CardTitle>
                <CardDescription>
                  <p className="font-semibold text-blue-600 dark:text-blue-400 mb-2">
                    Bill Number: {group.bill.billNumber} - 
                    <a href={group.bill.url} target="_blank" rel="noopener noreferrer" className="ml-2 text-blue-500 hover:text-blue-700 underline">
                      View Full Text
                    </a>
                  </p>
                  {group.bill.description}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mt-4">
                  <h3 className="text-lg font-semibold mb-2">Related News</h3>
                  <div className="flex space-x-2 mb-4">
                    {newsSources.map((source) => (
                      <Button
                        key={source.name}
                        variant={selectedSources[group.bill.id] === source.name ? "default" : "outline"}
                        onClick={() => handleSourceSelect(group.bill.id, source.name)}
                        className="flex items-center space-x-2"
                      >
                        <img src={source.logo} alt={source.name} className="w-6 h-6 object-contain" />
                        <span>{source.name}</span>
                      </Button>
                    ))}
                  </div>
                  <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-md">
                    {selectedSources[group.bill.id] && group.relatedNews[selectedSources[group.bill.id]] ? (
                      <>
                        <a href={group.relatedNews[selectedSources[group.bill.id]].url} target="_blank" rel="noopener noreferrer" className="text-blue-600 dark:text-blue-400 hover:underline">
                          {group.relatedNews[selectedSources[group.bill.id]].title}
                        </a>
                        <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">Source: {group.relatedNews[selectedSources[group.bill.id]].source}</p>
                      </>
                    ) : (
                      <p>Select a news source to view related articles.</p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default NewBills;