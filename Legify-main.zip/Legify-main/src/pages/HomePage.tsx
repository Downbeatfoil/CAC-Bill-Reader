import { Link } from 'react-router-dom';
import { FileText, BookOpen, Users } from 'lucide-react';
import { useState, useEffect } from 'react';

const HomePage = () => {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (event) => {
      setMousePosition({ x: event.clientX, y: event.clientY });
    };

    window.addEventListener('mousemove', handleMouseMove);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  return (
    <div className="container mx-auto px-4 py-12 relative min-h-screen overflow-hidden">
      <div className="absolute inset-0 z-0">
        <div 
          className="absolute inset-0 bg-gradient-to-br from-green-400 to-blue-500 animate-gradient-x"
          style={{
            transform: `translate(${mousePosition.x / 100}px, ${mousePosition.y / 100}px)`,
            transition: 'transform 0.1s ease-out',
          }}
        ></div>
      </div>
      <div className="relative z-10">
        <h1 className="text-4xl md:text-6xl font-bold text-center text-white mb-6">
          Legify
        </h1>
        <p className="text-xl text-center text-white mb-12">
          Stay Informed About Congressional Bills and Your Representatives.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <Link to="/summarize" className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 flex flex-col items-center transition-all duration-300 transform hover:scale-105 hover:shadow-xl hover:bg-green-100 dark:hover:bg-green-900">
            <FileText size={48} className="text-green-500 mb-4 transition-transform duration-300 group-hover:scale-110" />
            <h2 className="text-2xl font-semibold mb-2 text-gray-800 dark:text-white group-hover:text-green-600 dark:group-hover:text-green-400">Bill Summarizer</h2>
            <p className="text-center text-gray-600 dark:text-gray-300 group-hover:text-green-700 dark:group-hover:text-green-300">Get concise summaries of complex bills</p>
          </Link>
          <Link to="/new-bills" className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 flex flex-col items-center transition-all duration-300 transform hover:scale-105 hover:shadow-xl hover:bg-blue-100 dark:hover:bg-blue-900">
            <BookOpen size={48} className="text-blue-500 mb-4 transition-transform duration-300 group-hover:scale-110" />
            <h2 className="text-2xl font-semibold mb-2 text-gray-800 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400">New Bills</h2>
            <p className="text-center text-gray-600 dark:text-gray-300 group-hover:text-blue-700 dark:group-hover:text-blue-300">Stay updated on the latest legislative proposals</p>
          </Link>
          <Link to="/find-representative" className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 flex flex-col items-center transition-all duration-300 transform hover:scale-105 hover:shadow-xl hover:bg-purple-100 dark:hover:bg-purple-900">
            <Users size={48} className="text-purple-500 mb-4 transition-transform duration-300 group-hover:scale-110" />
            <h2 className="text-2xl font-semibold mb-2 text-center text-gray-800 dark:text-white group-hover:text-purple-600 dark:group-hover:text-purple-400">Find Representative</h2>
            <p className="text-center text-gray-600 dark:text-gray-300 group-hover:text-purple-700 dark:group-hover:text-purple-300">Locate your local Congress members</p>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default HomePage;