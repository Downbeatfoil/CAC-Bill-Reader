import React from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { GoogleGenerativeAI } from "@google/generative-ai";

const genAI = new GoogleGenerativeAI('AIzaSyDT9ddQECPsz_yJRKhNhS3mjWWr0OY1rdk');

const BillSummarizer: React.FC = () => {
  const [inputType, setInputType] = React.useState<'text' | 'image' | 'url'>('text');
  const [input, setInput] = React.useState('');
  const [summary, setSummary] = React.useState('');
  const [isLoading, setIsLoading] = React.useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setSummary('');

    try {
      const model = genAI.getGenerativeModel({ model: "gemini-pro" });

      const prompt = `Summarize this bill into one paragraph that is simple for the average American to understand. Use a Spartan, conversational tone with less corporate jargon: ${input}`;

      const result = await model.generateContent(prompt);
      const response = await result.response;
      const summarizedText = response.text();

      setSummary(summarizedText || 'No summary generated.');
      toast({
        title: "Summary Generated",
        description: "The bill has been successfully summarized.",
      });
    } catch (error) {
      console.error('Error summarizing bill:', error);
      toast({
        title: "Error",
        description: "Failed to generate summary. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold text-center text-white mb-8">Bill Summarizer</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <Card className="p-6">
          <form onSubmit={handleSubmit}>
            <RadioGroup
              defaultValue="text"
              className="mb-4"
              onValueChange={(value) => setInputType(value as 'text' | 'image' | 'url')}
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="text" id="text" />
                <Label htmlFor="text">Text Input</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="image" id="image" />
                <Label htmlFor="image">Image Upload</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="url" id="url" />
                <Label htmlFor="url">URL Input</Label>
              </div>
            </RadioGroup>

            {inputType === 'text' && (
              <Textarea
                placeholder="Enter Bill Content..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                className="mb-4"
                rows={10}
              />
            )}
            {inputType === 'image' && (
              <Input
                type="file"
                accept="image/*"
                onChange={(e) => setInput(e.target.files?.[0]?.name || '')}
                className="mb-4"
              />
            )}
            {inputType === 'url' && (
              <Input
                type="url"
                placeholder="Enter URL of the bill..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
                className="mb-4"
              />
            )}
            
            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? 'Summarizing...' : 'Summarize'}
            </Button>
          </form>
        </Card>
        <Card className="p-6">
          <h2 className="text-2xl font-semibold mb-4">Summary</h2>
          <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-md min-h-[200px]">
            {isLoading ? (
              <p>Generating summary...</p>
            ) : (
              summary || 'The Summarized Bill Will Appear Here...'
            )}
          </div>
        </Card>
      </div>
    </div>
  );
};

export default BillSummarizer;