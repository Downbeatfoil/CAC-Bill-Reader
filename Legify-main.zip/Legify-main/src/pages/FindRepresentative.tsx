import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { getDistrictNumber } from '../utils/districtUtils';
import { fetchCitiesInDistrict } from '../utils/cityUtils';
import CityMap from '../components/CityMap';
import { ExternalLink } from 'lucide-react';

const states = [
  'Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California', 'Colorado', 'Connecticut', 'Delaware', 'Florida', 'Georgia',
  'Hawaii', 'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky', 'Louisiana', 'Maine', 'Maryland',
  'Massachusetts', 'Michigan', 'Minnesota', 'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire', 'New Jersey',
  'New Mexico', 'New York', 'North Carolina', 'North Dakota', 'Ohio', 'Oklahoma', 'Oregon', 'Pennsylvania', 'Rhode Island', 'South Carolina',
  'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont', 'Virginia', 'Washington', 'West Virginia', 'Wisconsin', 'Wyoming'
];

const API_KEY = 'AIzaSyA-rmZF1d_X6_oCXSyUMj5IY1qQhFaHskk';

interface RepresentativeData {
  officials: Array<{
    name: string;
    photoUrl?: string;
    urls?: string[];
  }>;
  offices: Array<{
    name: string;
    divisionId: string;
    officialIndices: number[];
  }>;
  normalizedInput?: {
    state: string;
  };
}

const fetchRepresentative = async ({ zipCode, street, city, state }): Promise<RepresentativeData> => {
  if (!API_KEY) {
    throw new Error('Google Civic API key is not set');
  }
  const address = `${street}, ${city}, ${state} ${zipCode}`;
  const url = `https://www.googleapis.com/civicinfo/v2/representatives?key=${API_KEY}&address=${encodeURIComponent(address)}&levels=country&roles=legislatorLowerBody`;
  
  const response = await fetch(url);
  if (!response.ok) {
    const errorData = await response.json();
    if (response.status === 403 && errorData.error && errorData.error.message) {
      if (errorData.error.message.includes("API has not been used in project") || 
          errorData.error.message.includes("API is disabled")) {
        throw new Error("The Google Civic Information API is not enabled for this project. Please contact the administrator to enable it.");
      }
      throw new Error(`API Error: ${errorData.error.message}`);
    }
    throw new Error('Failed to fetch representative data');
  }
  return response.json();
};

const FindRepresentative: React.FC = () => {
  const [zipCode, setZipCode] = useState('');
  const [street, setStreet] = useState('');
  const [city, setCity] = useState('');
  const [state, setState] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [cities, setCities] = useState<string[]>([]);

  const { data, isLoading, error, refetch } = useQuery<RepresentativeData, Error>({
    queryKey: ['representative', zipCode, street, city, state],
    queryFn: () => fetchRepresentative({ zipCode, street, city, state }),
    enabled: false,
  });

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSubmitted(true);
    refetch();
  };

  const representativeImage = "https://d12t4t5x3vyizu.cloudfront.net/nikemawilliams.house.gov/uploads/2022/03/Congresswoman_Nikema_Williams_Official_Portrait-scaled.jpg";

  React.useEffect(() => {
    if (data?.normalizedInput?.state) {
      const { state } = data.normalizedInput;
      const districtNumber = getDistrictNumber(data.offices);
      
      fetchCitiesInDistrict(state, districtNumber).then(citiesData => {
        setCities(citiesData);
      });
    }
  }, [data]);

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold text-center text-white mb-8">Find Your Congressional Representative</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg">
          <form onSubmit={handleSubmit} className="space-y-4">
            <Input
              type="text"
              placeholder="Zip Code"
              value={zipCode}
              onChange={(e) => setZipCode(e.target.value)}
              required
            />
            <Input
              type="text"
              placeholder="Street Address"
              value={street}
              onChange={(e) => setStreet(e.target.value)}
              required
            />
            <Input
              type="text"
              placeholder="City"
              value={city}
              onChange={(e) => setCity(e.target.value)}
              required
            />
            <Select onValueChange={setState} required>
              <SelectTrigger>
                <SelectValue placeholder="Select State" />
              </SelectTrigger>
              <SelectContent>
                {states.map((s) => (
                  <SelectItem key={s} value={s}>{s}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button type="submit" className="w-full">Find Your Representative</Button>
          </form>
        </div>
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg">
          {isLoading && <p>Loading...</p>}
          {error && <p className="text-red-500">Error: {error.message}</p>}
          {data && submitted && (
            <div className="text-center">
              {data.officials && data.officials[0] ? (
                <>
                  <img 
                    src={representativeImage} 
                    alt={data.officials[0].name} 
                    className="w-48 h-48 object-cover mb-4 rounded-full mx-auto shadow-lg"
                  />
                  <h2 className="text-2xl font-bold mb-2">{data.officials[0].name}</h2>
                  <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-lg mb-4">
                    <p className="mb-2"><span className="font-semibold">District:</span> {getDistrictNumber(data.offices)}</p>
                    <p className="mb-2"><span className="font-semibold">State:</span> {data.normalizedInput?.state || state}</p>
                    {cities.length > 0 && (
                      <p className="mb-2"><span className="font-semibold">Cities:</span> {cities.join(', ')}</p>
                    )}
                  </div>
                  {data.officials[0].urls && (
                    <a 
                      href={data.officials[0].urls[0]} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="inline-flex items-center mt-4 px-6 py-3 bg-blue-500 text-white rounded-full hover:bg-blue-600 transition-colors text-lg font-semibold shadow-md"
                    >
                      Visit Official Website
                      <ExternalLink className="ml-2 h-5 w-5" />
                    </a>
                  )}
                </>
              ) : (
                <p>No representative found for the given address.</p>
              )}
            </div>
          )}
        </div>
      </div>
      <CityMap city={city} />
    </div>
  );
};

export default FindRepresentative;