import React, { useEffect, useRef, useState } from 'react';
import Map from 'ol/Map';
import View from 'ol/View';
import TileLayer from 'ol/layer/Tile';
import OSM from 'ol/source/OSM';
import { fromLonLat } from 'ol/proj';
import 'ol/ol.css';

interface CityMapProps {
  city: string;
}

const CityMap: React.FC<CityMapProps> = ({ city }) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<Map | null>(null);
  const [coordinates, setCoordinates] = useState<[number, number] | null>(null);

  useEffect(() => {
    if (mapRef.current && !mapInstanceRef.current) {
      mapInstanceRef.current = new Map({
        target: mapRef.current,
        layers: [
          new TileLayer({
            source: new OSM(),
          }),
        ],
        view: new View({
          center: fromLonLat([-98.5795, 39.8283]), // Center on the US
          zoom: 4,
        }),
      });
    }
  }, []);

  useEffect(() => {
    const fetchCityCoordinates = async () => {
      if (city) {
        try {
          const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(city)}`);
          const data = await response.json();
          if (data && data.length > 0) {
            setCoordinates([parseFloat(data[0].lon), parseFloat(data[0].lat)]);
          }
        } catch (error) {
          console.error('Error fetching city coordinates:', error);
        }
      }
    };

    fetchCityCoordinates();
  }, [city]);

  useEffect(() => {
    if (mapInstanceRef.current && coordinates) {
      const view = mapInstanceRef.current.getView();
      view.animate({
        center: fromLonLat(coordinates),
        zoom: 10, // Increased zoom level from 8 to 10
        duration: 2000,
      });
    }
  }, [coordinates]);

  return <div ref={mapRef} className="w-full h-[400px] mt-8 rounded-lg overflow-hidden"></div>;
};

export default CityMap;